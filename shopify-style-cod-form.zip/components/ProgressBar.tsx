import React from 'react';

interface ProgressBarProps {
  currentStep: number;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({ currentStep }) => {
  const steps = [
    { id: 1, name: 'Details' },
    { id: 2, name: 'Confirm Order' },
  ];

  return (
    <div className="flex items-center justify-center space-x-2 text-sm text-gray-500">
      {steps.map((step, index) => (
        <React.Fragment key={step.id}>
          <div
            className={`flex items-center ${
              currentStep >= step.id ? 'text-green-600 font-bold' : ''
            }`}
          >
            <div
              className={`w-5 h-5 rounded-full flex items-center justify-center mr-2 ${
                currentStep >= step.id ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-500'
              }`}
            >
              {step.id}
            </div>
            {`Step ${step.id}: ${step.name}`}
          </div>
          {index < steps.length - 1 && (
            <div className="text-gray-300">→</div>
          )}
        </React.Fragment>
      ))}
    </div>
  );
};
