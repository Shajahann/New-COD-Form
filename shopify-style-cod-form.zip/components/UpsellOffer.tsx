import React from 'react';

interface UpsellOfferProps {
  isChecked: boolean;
  onToggle: () => void;
}

export const UpsellOffer: React.FC<UpsellOfferProps> = ({ isChecked, onToggle }) => {
  return (
    <div className="bg-yellow-50/50 p-5 border-t border-gray-200">
       <h3 className="text-lg font-bold text-center text-gray-800 mb-3">🔥 Special Offer for You</h3>
       <div className={`bg-yellow-100 border-2 ${isChecked ? 'border-green-500' : 'border-yellow-300'} rounded-lg p-4 shadow-[0_0_20px_rgba(251,191,36,0.4)] transition-all duration-300`}>
        <div className="flex items-center gap-4">
          <img src="https://picsum.photos/80/80?random=1" alt="Upsell Product" className="w-16 h-16 rounded-md object-cover flex-shrink-0" />
          <div className="flex-grow">
            <p className="font-bold text-gray-800">Add a 2nd Item for 30% Off!</p>
            <p className="text-sm text-gray-600">Get our best-selling smartwatch at a huge discount.</p>
          </div>
        </div>
        <label className="mt-4 flex items-center cursor-pointer bg-white p-3 rounded-lg border border-gray-200 hover:bg-gray-50">
          <input
            type="checkbox"
            checked={isChecked}
            onChange={onToggle}
            className="h-5 w-5 rounded text-green-600 border-gray-300 focus:ring-green-500"
          />
          <span className="ml-3 text-sm font-medium text-gray-700">Yes, add this to my order for just <span className="font-bold">Rs. 1,499!</span></span>
        </label>
      </div>
    </div>
  );
};
