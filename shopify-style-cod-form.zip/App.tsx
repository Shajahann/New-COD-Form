import React, { useState } from 'react';
import { ProgressBar } from './components/ProgressBar';
import { InputField } from './components/InputField';
import { CartIcon } from './components/icons/CartIcon';
import { LockIcon } from './components/icons/LockIcon';
import { UserIcon } from './components/icons/UserIcon';
import { PhoneIcon } from './components/icons/PhoneIcon';
import { LocationIcon } from './components/icons/LocationIcon';
import { CityIcon } from './components/icons/CityIcon';
import { PriceTagIcon } from './components/icons/PriceTagIcon';
import { TruckIcon } from './components/icons/TruckIcon';

const product = {
  title: "Premium Smartwatch X1",
  price: "Rs. 2,499",
  imageUrl: "https://picsum.photos/80/80?random=product"
};

const App: React.FC = () => {
  const [formData, setFormData] = useState({
    fullName: '',
    phone: '',
    address: '',
    city: '',
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log("Order Submitted:", formData);
    alert("Order placed successfully! Check console for details.");
  };

  return (
    <div className="bg-gray-100 min-h-screen font-sans flex items-center justify-center p-4">
      <div className="w-full max-w-lg mx-auto bg-white rounded-xl shadow-2xl">
        <div className="p-6 sm:p-8">
          {/* Product Info Header */}
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center gap-4">
              <img src={product.imageUrl} alt={product.title} className="w-16 h-16 rounded-md object-cover" />
              <h2 className="font-semibold text-gray-700">{product.title}</h2>
            </div>
            <p className="font-bold text-lg text-gray-800">{product.price}</p>
          </div>

          <ProgressBar currentStep={1} />
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 text-center mt-4 mb-6">
            Complete Your Order
            <span className="block text-lg text-gray-500 font-normal">Cash on Delivery Available</span>
          </h1>
          
          <form onSubmit={handleSubmit} className="space-y-4">
            <InputField
              id="fullName"
              label="Full Name"
              placeholder="Enter Full Name"
              value={formData.fullName}
              onChange={handleInputChange}
              icon={<UserIcon />}
              required
            />
            <InputField
              id="phone"
              label="Phone Number"
              type="tel"
              placeholder="e.g. 03001234567"
              value={formData.phone}
              onChange={handleInputChange}
              icon={<PhoneIcon />}
              required
            />
            <InputField
              id="address"
              label="Address"
              placeholder="Enter Full Address"
              value={formData.address}
              onChange={handleInputChange}
              icon={<LocationIcon />}
              required
            />
            <InputField
              id="city"
              label="City"
              placeholder="Enter City"
              value={formData.city}
              onChange={handleInputChange}
              icon={<CityIcon />}
              required
            />

            {/* Order Summary Section */}
            <div className="bg-[#E8EBE9] p-4 rounded-lg">
              <div className="flex justify-between items-center text-gray-600 pb-2">
                <div className="flex items-center gap-2">
                  <PriceTagIcon />
                  <span>Subtotal</span>
                </div>
                <span className="font-semibold text-gray-800">{product.price}</span>
              </div>
              <div className="flex justify-between items-center text-gray-600 border-t border-gray-300 pt-2">
                <div className="flex items-center gap-2">
                  <TruckIcon />
                  <span>Shipping Method</span>
                </div>
                <span className="font-semibold text-gray-800">Free</span>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="submit"
                className="w-full bg-green-600 text-white font-bold py-4 px-4 rounded-lg flex items-center justify-center gap-2 text-lg hover:bg-green-700 transition-all duration-300 focus:outline-none focus:ring-4 focus:ring-green-300 transform hover:scale-105"
              >
                <CartIcon />
                Place Order Now
              </button>
            </div>
          </form>

          <div className="mt-4 flex items-center justify-center text-gray-500 text-sm">
            <LockIcon />
            <span className="ml-2">Secure COD Checkout – No Advance Payment Needed.</span>
          </div>

        </div>
      </div>
    </div>
  );
};

export default App;